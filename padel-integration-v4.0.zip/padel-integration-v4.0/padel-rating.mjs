// Padel Level Lab 4.0 — extracted from the published quiz; no DOM, network or dependencies.
    const TEST_VERSION = 'padel-level-lab-4.0';
    const LETTERS = ['A', 'B', 'C', 'D', 'E'];
    const QUESTIONS = [
      {
        id:'experience', short:'Опыт игры', weight:1, group:'easy',
        title:'Сколько у вас опыта игры в падел?',
        options:[
          'Ещё не играл или попробовал всего 1–2 раза.',
          'Начал недавно: играю меньше трёх месяцев.',
          'Играю от трёх месяцев до года.',
          'Играю от года до двух лет.',
          'Играю больше двух лет.'
        ]
      },
      {
        id:'rally', short:'Поддержание розыгрыша', weight:1, group:'easy',
        title:'Получается ли у вас несколько раз подряд вернуть мяч без ошибки?',
        options:[
          'Часто ошибаюсь уже на первом или втором мяче.',
          'Обычно возвращаю 3–5 удобных мячей подряд.',
          'На спокойной скорости поддерживаю розыгрыш из 6–10 ударов.',
          'Могу долго держать мяч в игре справа и слева, но при ускорениях ещё ошибаюсь.',
          'Уверенно поддерживаю быстрый розыгрыш и могу менять направление и высоту мяча.'
        ]
      },
      {
        id:'serve-return', short:'Подача и приём', weight:1, group:'easy',
        title:'Насколько уверенно вы подаёте и принимаете подачу?',
        explanation:'Если подача и приём получаются по-разному, ориентируйтесь на то, что даётся сложнее.',
        options:[
          'Пока осваиваю правила и часто не могу ввести мяч в игру.',
          'Иногда подаю и принимаю удачно, но ошибок ещё много.',
          'Обычно начинаю розыгрыш без ошибки, если мяч не слишком сложный.',
          'Стабильно подаю и принимаю, стараюсь направить мяч в выбранную часть корта.',
          'Уверенно выбираю направление и глубину, чтобы получить удобный следующий удар.'
        ]
      },
      {
        id:'positioning', short:'Позиция и движение', weight:1, group:'easy',
        title:'Понимаете ли вы, где стоять и куда двигаться во время игры?',
        options:[
          'Часто не понимаю, где моя позиция и чей это мяч.',
          'Знаю основные места на корте, но часто оказываюсь далеко от мяча.',
          'Обычно занимаю удобную позицию, но в быстрых розыгрышах теряюсь.',
          'Двигаюсь вместе с партнёром, прикрываю свободное место и вовремя возвращаюсь назад.',
          'Заранее читаю действия соперников и постоянно подстраиваю позицию вместе с партнёром.'
        ]
      },
      {
        id:'glass-defense', short:'Игра после стекла', weight:3, group:'game', foundation:true,
        title:'Как вы возвращаете мяч после отскока от стекла?',
        explanation:'Вспомните мячи у задней стенки и в углу: успеваете ли вы подойти к отскоку и направить ответ?',
        options:[
          'Обычно теряю такой мяч или стараюсь не допустить отскока от стекла.',
          'Возвращаю простой медленный мяч от заднего стекла, но в углу часто ошибаюсь.',
          'Часто возвращаю обычный мяч от заднего стекла; сложные отскоки в углу пока даются тяжело.',
          'В матчах уверенно играю от заднего стекла и после двух стенок, могу выбрать направление ответа.',
          'Даже при быстрых и низких отскоках сохраняю контроль, направляю ответ и успеваю восстановить позицию.'
        ]
      },
      {
        id:'lob', short:'Свеча', weight:3, group:'game', foundation:true,
        title:'Получается ли у вас перебросить соперников у сетки — сыграть свечу?',
        explanation:'Свеча — высокий мяч над соперниками. Хорошая свеча заставляет их отойти назад и даёт вам время занять удобную позицию.',
        options:[
          'Часто попадаю в сетку, бью за корт или оставляю соперникам удобный мяч для атаки.',
          'Иногда перебрасываю соперников с удобного мяча, но длину пока контролирую плохо.',
          'С удобного мяча часто выполняю глубокую свечу, но в движении или из защиты ошибаюсь.',
          'В матчах выполняю глубокую свечу и из защиты, чтобы восстановить позицию или выйти вперёд.',
          'При быстрой игре уверенно выбираю высоту, глубину и направление свечи и использую её в подходящий момент.'
        ]
      },
      {
        id:'volley', short:'Воллей — удар с лёта', weight:3, group:'technical', foundation:true,
        title:'Воллей: как вы играете с лёта у сетки?',
        explanation:'Воллей — удар до отскока мяча от пола. Оценивайте и правую, и левую сторону по той, которая получается менее уверенно.',
        options:[
          'Пока редко играю с лёта или часто ошибаюсь даже на удобном мяче.',
          'Возвращаю простые мячи, но быстрые и низкие часто не успеваю обработать.',
          'Стабильно играю с лёта на средней скорости, но сложные мячи часто поднимаю под атаку.',
          'В матчах делаю короткое движение ракеткой, справляюсь с быстрыми и низкими мячами и направляю ответ.',
          'На высоком темпе управляю глубиной и направлением, смягчаю быстрые мячи и сохраняю давление несколькими ударами подряд.'
        ]
      },
      {
        id:'bandeja', short:'Бандеха', weight:3, group:'technical',
        title:'Бандеха: как вы возвращаете высокие мячи, сохраняя сетку?',
        explanation:'Бандеха (bandeja) — контролируемый удар над головой в ответ на свечу. Его цель — вернуть мяч с контролем и остаться в выгодной позиции у сетки.',
        options:[
          'Пока не выполняю такой удар или обычно пропускаю высокий мяч к стеклу.',
          'Пробую на удобных мячах, но в матче часто теряю равновесие или направление.',
          'С удобной позиции контролирую удар, но при отходе назад часто оставляю короткий высокий мяч.',
          'В матчах успеваю отойти под мяч, направляю удар в нужную зону и возвращаюсь к сетке.',
          'Даже после глубоких свечей и под давлением сохраняю качество, меняю направление и удерживаю позицию у сетки.'
        ]
      },
      {
        id:'bajada', short:'Бахада', weight:3, group:'technical',
        title:'Бахада: как вы атакуете после высокого отскока от стекла?',
        explanation:'Бахада (bajada) — атакующий удар после высокого отскока от заднего стекла. Нужно вовремя подойти к мячу и направить его в неудобное для соперников место.',
        options:[
          'Пока не выполняю такой удар: стараюсь просто вернуть мяч в игру.',
          'Пробую атаковать, но часто опаздываю или ошибаюсь из-за слишком сильного удара.',
          'Атакую удобный высокий отскок, но в матче точность и качество пока нестабильны.',
          'В матчах вовремя подхожу к отскоку, атакую в выбранную зону и готовлю следующий удар.',
          'При быстрой игре читаю отскок и позицию соперников, точно направляю мяч в ноги или свободное место и продолжаю атаку.'
        ]
      },
      {
        id:'starter-contact', short:'Контакт с мячом', weight:1, group:'easy',
        title:'Легко ли вам попасть ракеткой по спокойному удобному мячу?',
        options:[
          'Пока часто промахиваюсь или только собираюсь попробовать игру.',
          'Иногда попадаю удачно, но контакт с мячом ещё непредсказуемый.',
          'Регулярно попадаю по спокойному мячу, но не всегда возвращаю его через сетку.',
          'Уверенно возвращаю удобный мяч через сетку справа и слева.',
          'На обычной скорости хорошо контролирую контакт и могу направить удобный мяч.'
        ]
      },
      {
        id:'starter-direction', short:'Направление простого удара', weight:1, group:'easy',
        title:'Получается ли направить простой мяч в выбранную сторону?',
        options:[
          'Пока стараюсь просто коснуться мяча; направление не выбираю.',
          'Иногда попадаю в нужную сторону, но чаще мяч летит случайно.',
          'С удобного мяча могу выбрать левую или правую половину корта.',
          'Обычно направляю спокойный мяч в выбранную половину и контролирую силу.',
          'Уверенно направляю удобные мячи в разные зоны, делаю их короче или глубже.'
        ]
      },
      {
        id:'starter-recovery', short:'Готовность к следующему мячу', weight:1, group:'easy',
        title:'После своего удара успеваете ли вы подготовиться к следующему мячу?',
        options:[
          'Обычно остаюсь на месте и поздно замечаю следующий мяч.',
          'Вспоминаю о подготовке, но часто начинаю двигаться слишком поздно.',
          'После спокойного удара возвращаюсь в удобное место и поднимаю ракетку.',
          'Обычно успеваю восстановить позицию, смотрю на соперника и готовлю ракетку.',
          'Регулярно готовлюсь к следующему удару заранее, даже если пришлось побежать за мячом.'
        ]
      },
      {
        id:'developing-low', short:'Низкие и неудобные мячи', weight:2, group:'game',
        title:'Как вы возвращаете низкий мяч, к которому приходится подбежать?',
        options:[
          'Чаще всего не успеваю к мячу или не могу его вернуть.',
          'Иногда успеваю, но обычно отправляю мяч в сетку или за корт.',
          'На спокойной скорости возвращаю такой мяч, но часто оставляю сопернику удобную атаку.',
          'В матчах подхожу ногами, возвращаю мяч с запасом и стараюсь восстановить позицию.',
          'При быстрой игре сохраняю контроль низкого мяча и выбираю высоту и глубину ответа.'
        ]
      },
      {
        id:'developing-net', short:'Простая игра у сетки', weight:2, group:'game',
        title:'Получается ли у сетки вернуть мяч до его отскока от пола?',
        explanation:'Вспомните короткие удары рядом с сеткой: успеваете ли подставить ракетку и сохранить контроль?',
        options:[
          'Пока избегаю таких ударов или часто ошибаюсь даже на удобном мяче.',
          'Возвращаю простой медленный мяч, но быстрые мячи вызывают трудности.',
          'На средней скорости играю справа и слева, но низкие мячи часто поднимаю под атаку.',
          'В матчах делаю короткое движение ракеткой и направляю ответ, в том числе с неудобного мяча.',
          'При быстрой игре меняю направление и глубину, смягчаю сильные мячи и удерживаю позицию у сетки.'
        ]
      },
      {
        id:'developing-high', short:'Контроль высокого мяча', weight:2, group:'game',
        title:'Получается ли вернуть высокий мяч над головой, сохраняя равновесие?',
        options:[
          'Часто промахиваюсь или стараюсь пропустить мяч назад.',
          'Возвращаю удобный высокий мяч, но плохо контролирую направление.',
          'Из спокойной позиции направляю мяч через сетку, но при отходе назад часто ошибаюсь.',
          'В матчах успеваю переместиться под высокий мяч, направляю ответ и возвращаюсь вперёд.',
          'Даже при глубоком высоком мяче и в движении сохраняю контроль, выбираю направление и удобную позицию.'
        ]
      }
    ];

    const QUESTION_COUNT = 9;
    const QUESTION_BY_ID = Object.fromEntries(QUESTIONS.map(question => [question.id, question]));
    const SHARED_IDS = ['experience','rally','serve-return','positioning','glass-defense','lob'];
    const BRANCHES = {
      beginner:{id:'beginner',number:1,name:'Первые шаги',condition:'Оба первых ответа — A или B',tailIds:['starter-contact','starter-direction','starter-recovery'],keySkillIds:['rally','glass-defense','lob']},
      developing:{id:'developing',number:2,name:'Уверенная база',condition:'Ровно один из первых ответов — A или B',tailIds:['developing-low','developing-net','developing-high'],keySkillIds:['rally','glass-defense','lob']},
      standard:{id:'standard',number:3,name:'Полный тест',condition:'Оба первых ответа — C, D или E',tailIds:['volley','bandeja','bajada'],keySkillIds:['glass-defense','lob','volley']}
    };
    const TAIL_IDS = Object.values(BRANCHES).flatMap(branch => branch.tailIds);
    const MAX_POINTS = [...SHARED_IDS,...BRANCHES.standard.tailIds].reduce((total,id) => total + 4 * QUESTION_BY_ID[id].weight, 0);
    const SCORING = Object.freeze({ fundamentalsShare:0.2, exponent:1.25 });

    function createAnswers() {
      return Object.fromEntries(QUESTIONS.map(question => [question.id,null]));
    }

    function isAnswer(value) {
      return Number.isInteger(value) && value >= 0 && value <= 4;
    }

    function getBranch(responses = createAnswers()) {
      if (!responses || !isAnswer(responses.experience) || !isAnswer(responses.rally)) return null;
      const lowCount = Number(responses.experience <= 1) + Number(responses.rally <= 1);
      return lowCount === 2 ? BRANCHES.beginner : lowCount === 1 ? BRANCHES.developing : BRANCHES.standard;
    }

    function getActiveQuestions(responses = createAnswers()) {
      const branch = getBranch(responses);
      return (branch ? [...SHARED_IDS,...branch.tailIds] : SHARED_IDS.slice(0,2)).map(id => QUESTION_BY_ID[id]);
    }


    // Returns a new state; switching branches clears every branch-specific answer.
    function setAnswer(responses, id, value) {
      if (!responses || typeof responses !== 'object' || Array.isArray(responses)) {
        throw new TypeError('Ожидается объект ответов.');
      }
      if (!Object.prototype.hasOwnProperty.call(QUESTION_BY_ID, id) || !isAnswer(value)) {
        throw new Error('Некорректный ответ.');
      }
      const previousBranch = getBranch(responses)?.id;
      const next = Object.fromEntries(QUESTIONS.map(question => [question.id, responses[question.id] ?? null]));
      next[id] = value;
      if (previousBranch !== getBranch(next)?.id) {
        TAIL_IDS.forEach(tailId => { next[tailId] = null; });
      }
      return next;
    }
    function calculateResult(selectedAnswers) {
      const branch = getBranch(selectedAnswers);
      const questions = getActiveQuestions(selectedAnswers);
      if (!branch || questions.length !== QUESTION_COUNT || !questions.every(question => isAnswer(selectedAnswers[question.id]))) {
        throw new Error(`Для расчёта нужно ответить на все ${QUESTION_COUNT} вопросов.`);
      }
      const weightedPoints = questions.reduce((total,question) => total + selectedAnswers[question.id] * question.weight, 0);
      const availableMaxPoints = questions.reduce((total,question) => total + 4 * question.weight, 0);
      const weakestFoundationPoints = Math.min(...branch.keySkillIds.map(id => selectedAnswers[id]));
      const normalizedWeightedScore = weightedPoints / MAX_POINTS;
      const effectiveScore = (1 - SCORING.fundamentalsShare) * normalizedWeightedScore + SCORING.fundamentalsShare * weakestFoundationPoints / 4;
      const rating = Math.round((1 + 4 * Math.pow(effectiveScore, SCORING.exponent)) * 10) / 10;
      return { branchId:branch.id,branchName:branch.name,weightedPoints,availableMaxPoints,maxPoints:MAX_POINTS,normalizedWeightedScore,weakestFoundationPoints,effectiveScore,rating };
    }


    // Consumers may render these definitions, but must not alter the shared scoring model.
    function deepFreeze(value) {
      if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.values(value).forEach(deepFreeze);
        Object.freeze(value);
      }
      return value;
    }
    [LETTERS, QUESTIONS, SHARED_IDS, BRANCHES].forEach(deepFreeze);

export { TEST_VERSION, LETTERS, QUESTIONS, QUESTION_COUNT, SHARED_IDS, BRANCHES, MAX_POINTS, SCORING, createAnswers, isAnswer, getBranch, getActiveQuestions, setAnswer, calculateResult };
