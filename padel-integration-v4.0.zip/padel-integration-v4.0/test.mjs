import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import {
  TEST_VERSION, LETTERS, QUESTIONS, QUESTION_COUNT, SHARED_IDS,
  BRANCHES, MAX_POINTS, SCORING, createAnswers, isAnswer,
  getBranch, getActiveQuestions, setAnswer, calculateResult
} from './padel-rating.mjs';

const readJson = name => JSON.parse(readFileSync(new URL(name, import.meta.url), 'utf8'));
const spec = readJson('./questions.json');
const vectors = readJson('./test-vectors.json');
const tails = Object.values(BRANCHES).flatMap(branch => branch.tailIds);
const html = readFileSync(new URL('./padel-test.html', import.meta.url), 'utf8');
const script = html.split('<script>')[1].split('</script>')[0];
const referenceContext = vm.createContext({ document: { getElementById: () => ({ innerHTML: '' }) } });
vm.runInContext(script.slice(0, script.indexOf('    function focusHeading()')) + '\nglobalThis.reference={QUESTIONS,getBranch,getActiveQuestions,calculateResult};', referenceContext);
const reference = referenceContext.reference;

test('JSON, module and standalone HTML describe the same version and questions', () => {
  assert.equal(TEST_VERSION, spec.testVersion);
  assert.equal(TEST_VERSION, vectors.testVersion);
  assert.equal(QUESTION_COUNT, 9);
  assert.equal(QUESTIONS.length, 15);
  assert.equal(new Set(QUESTIONS.map(q => q.id)).size, 15);
  assert.ok(QUESTIONS.every(q => q.options.length === 5));
  assert.deepEqual(spec.answerScale.map(x => x.letter), LETTERS);
  assert.deepEqual(spec.answerScale.map(x => x.points), [0, 1, 2, 3, 4]);
  assert.deepEqual(spec.questions, QUESTIONS);
  assert.deepEqual(JSON.parse(JSON.stringify(reference.QUESTIONS)), QUESTIONS);
  assert.deepEqual(spec.sharedQuestionIds, SHARED_IDS);
  assert.deepEqual(spec.branches, BRANCHES);
  assert.equal(spec.scoring.referenceMaxPoints, MAX_POINTS);
  assert.equal(spec.scoring.fundamentalsShare, SCORING.fundamentalsShare);
  assert.equal(spec.scoring.exponent, SCORING.exponent);
});

test('all 25 routing pairs, nine questions per route and pending routing', () => {
  assert.equal(getBranch(), null);
  assert.equal(getBranch({ experience: 1 }), null);
  assert.deepEqual(getActiveQuestions().map(q => q.id), ['experience', 'rally']);
  const counts = { beginner: 0, developing: 0, standard: 0 };
  for (let first = 0; first < 5; first++) for (let second = 0; second < 5; second++) {
    const answers = { experience: first, rally: second };
    const low = Number(first < 2) + Number(second < 2);
    const expected = low === 2 ? 'beginner' : low === 1 ? 'developing' : 'standard';
    assert.equal(getBranch(answers).id, expected);
    counts[expected]++;
    const ids = getActiveQuestions(answers).map(q => q.id);
    assert.equal(ids.length, 9);
    assert.deepEqual(ids.slice(0, 6), SHARED_IDS);
    assert.deepEqual(ids.slice(6), BRANCHES[expected].tailIds);
    if (expected !== 'standard') assert.ok(!ids.some(id => ['volley', 'bandeja', 'bajada'].includes(id)));
  }
  assert.deepEqual(counts, { beginner: 4, developing: 12, standard: 9 });
});

test('75 golden profiles match all result fields and the original HTML', () => {
  assert.equal(vectors.cases.length, 75);
  for (const vector of vectors.cases) {
    const actual = calculateResult(vector.answers);
    assert.deepEqual(getActiveQuestions(vector.answers).map(q => q.id), vector.expectedQuestionIds, vector.id);
    for (const [key, expected] of Object.entries(vector.expected)) {
      if (typeof expected === 'number') assert.ok(Math.abs(actual[key] - expected) <= vectors.numericTolerance, `${vector.id}: ${key}`);
      else assert.equal(actual[key], expected, `${vector.id}: ${key}`);
    }
    assert.deepEqual(JSON.parse(JSON.stringify(reference.calculateResult(vector.answers))), actual, vector.id);
  }
});

test('changing branches clears tail answers, preserves shared answers and does not mutate input', () => {
  const previous = Object.fromEntries(QUESTIONS.map(q => [q.id, 2]));
  const saved = { ...previous };
  const next = setAnswer(previous, 'experience', 1);
  assert.deepEqual(previous, saved);
  assert.notEqual(next, previous);
  assert.equal(getBranch(next).id, 'developing');
  assert.ok(tails.every(id => next[id] === null));
  assert.equal(next['glass-defense'], 2);
  const filled = setAnswer(next, 'developing-low', 3);
  const sameBranch = setAnswer(filled, 'experience', 0);
  assert.equal(sameBranch['developing-low'], 3);
  const beginner = setAnswer(sameBranch, 'rally', 1);
  assert.equal(getBranch(beginner).id, 'beginner');
  assert.ok(tails.every(id => beginner[id] === null));
  const standard = setAnswer(setAnswer(beginner, 'experience', 2), 'rally', 2);
  assert.equal(getBranch(standard).id, 'standard');
  assert.ok(tails.every(id => standard[id] === null));
});

test('inactive answers are ignored and incomplete or invalid answers cannot be scored', () => {
  for (const vector of vectors.cases) {
    const dirty = { ...vector.answers };
    for (const id of tails) if (!(id in dirty)) dirty[id] = 4;
    assert.deepEqual(calculateResult(dirty), calculateResult(vector.answers));
    const missing = { ...vector.answers, lob: null };
    assert.throws(() => calculateResult(missing));
  }
  for (const value of [null, undefined, 'A', '1', true, false, -1, 5, 1.5, NaN, Infinity]) {
    assert.equal(isAnswer(value), false);
    assert.equal(getBranch({ experience: value, rally: 2 }), null);
    assert.throws(() => setAnswer(createAnswers(), 'rally', value));
  }
  for (const id of ['unknown', '__proto__', 'constructor', 'toString']) assert.throws(() => setAnswer(createAnswers(), id, 2));
  assert.throws(() => calculateResult(createAnswers()));
  assert.throws(() => calculateResult(null));
  assert.throws(() => setAnswer(null, 'rally', 2));
});

test('shared denominator 76 and known calibration examples', () => {
  const result = (first, second, rest) => {
    const a = { experience: first, rally: second };
    getActiveQuestions(a).slice(2).forEach(q => { a[q.id] = rest; });
    return calculateResult(a);
  };
  assert.equal(result(1, 1, 2).rating, 1.9);
  assert.equal(result(1, 3, 2).rating, 2.4);
  assert.equal(result(3, 1, 2).rating, 2.2);
  assert.equal(result(2, 2, 2).rating, 2.7);
  assert.equal(result(3, 3, 3).rating, 3.8);
  assert.equal(result(0, 0, 0).rating, 1);
  assert.equal(result(4, 4, 4).rating, 5);
  assert.deepEqual([result(1, 1, 4).availableMaxPoints, result(1, 4, 4).availableMaxPoints, result(4, 4, 4).availableMaxPoints], [52, 64, 76]);
  assert.equal(result(1, 1, 4).maxPoints, 76);
  assert.equal(result(1, 1, 4).rating, 2.8);
});
