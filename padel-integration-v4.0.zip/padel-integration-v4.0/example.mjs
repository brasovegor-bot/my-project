import {
  createAnswers, setAnswer, getBranch, getActiveQuestions,
  calculateResult, TEST_VERSION
} from './padel-rating.mjs';

let answers = createAnswers();
answers = setAnswer(answers, 'experience', 1); // B
answers = setAnswer(answers, 'rally', 3);      // D => ветка 2

for (const question of getActiveQuestions(answers).slice(2)) {
  answers = setAnswer(answers, question.id, 2); // C
}

const branch = getBranch(answers);
const result = calculateResult(answers);
console.log(JSON.stringify({
  testVersion: TEST_VERSION,
  branchId: branch.id,
  rating: result.rating, // 2.4
  answers: Object.fromEntries(getActiveQuestions(answers).map(q => [q.id, answers[q.id]])),
  calculation: result
}, null, 2));
