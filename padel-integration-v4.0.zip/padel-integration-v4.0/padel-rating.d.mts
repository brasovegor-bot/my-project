export type Answer = 0 | 1 | 2 | 3 | 4;
export type BranchId = 'beginner' | 'developing' | 'standard';
export type QuestionId =
  | 'experience' | 'rally' | 'serve-return' | 'positioning'
  | 'glass-defense' | 'lob' | 'volley' | 'bandeja' | 'bajada'
  | 'starter-contact' | 'starter-direction' | 'starter-recovery'
  | 'developing-low' | 'developing-net' | 'developing-high';
export type Answers = Record<QuestionId, Answer | null>;
export type Responses = Partial<Answers>;
export interface Question {
  readonly id: QuestionId;
  readonly short: string;
  readonly title: string;
  readonly explanation?: string;
  readonly options: readonly string[];
  readonly weight: number;
  readonly group: 'easy' | 'game' | 'technical';
  readonly foundation?: boolean;
}
export interface Branch {
  readonly id: BranchId;
  readonly number: 1 | 2 | 3;
  readonly name: string;
  readonly condition: string;
  readonly tailIds: readonly QuestionId[];
  readonly keySkillIds: readonly QuestionId[];
}
export interface RatingResult {
  branchId: BranchId;
  branchName: string;
  weightedPoints: number;
  availableMaxPoints: number;
  maxPoints: number;
  normalizedWeightedScore: number;
  weakestFoundationPoints: number;
  effectiveScore: number;
  rating: number;
}
export const TEST_VERSION: 'padel-level-lab-4.0';
export const LETTERS: readonly ['A', 'B', 'C', 'D', 'E'];
export const QUESTIONS: readonly Question[];
export const QUESTION_COUNT: 9;
export const SHARED_IDS: readonly QuestionId[];
export const BRANCHES: Readonly<Record<BranchId, Branch>>;
export const MAX_POINTS: 76;
export const SCORING: Readonly<{ fundamentalsShare: 0.2; exponent: 1.25 }>;
export function createAnswers(): Answers;
export function isAnswer(value: unknown): value is Answer;
export function getBranch(responses?: Responses | null): Branch | null;
export function getActiveQuestions(responses?: Responses | null): Question[];
/** Returns a new state. Clears all branch-specific answers if the branch changes. */
export function setAnswer(responses: Responses, id: QuestionId, value: Answer): Answers;
/** Throws until all nine active answers contain integer indices 0..4. */
export function calculateResult(responses: Responses): RatingResult;
